document.addEventListener('DOMContentLoaded', function() {
    const audioPlayer = document.getElementById('audioPlayer');
    const playBtn = document.getElementById('playBtn');
    const pauseBtn = document.getElementById('pauseBtn');
    const stopBtn = document.getElementById('stopBtn');
    const musicFileInput = document.getElementById('musicFile');
    const fileLabel = document.querySelector('.file-label');

    let currentSource = null;

    playBtn.addEventListener('click', function() {
        audioPlayer.play();
    });

    pauseBtn.addEventListener('click', function() {
        audioPlayer.pause();
    });

    stopBtn.addEventListener('click', function() {
        audioPlayer.pause();
        audioPlayer.currentTime = 0;
    });

    musicFileInput.addEventListener('change', function(event) {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = function(e) {
                currentSource = e.target.result;
                audioPlayer.src = currentSource;
            };
            reader.readAsDataURL(file);
            fileLabel.textContent = `Selected file: ${file.name}`;
        }
    });
});
