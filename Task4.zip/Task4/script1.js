let currentUserType = "";

function openModal(userType) {
    const modal = document.getElementById('myModal');
    modal.style.display = 'block';
    currentUserType = userType;
}

function closeModal() {
    const modal = document.getElementById('myModal');
    modal.style.display = 'none';
}

function signIn() {
    const username = document.querySelector('.modal-content').querySelectorAll('input')[0].value;
    const password = document.querySelector('.modal-content').querySelectorAll('input')[1].value;

    // Perform sign-in logic here
    if (currentUserType === 'student') {
        window.location.href = "student1.html";
    } else if (currentUserType === 'admin') {
        window.location.href = "admin1.html";
    }

    // Clear the modal fields
    closeModal();
}
