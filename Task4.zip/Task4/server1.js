// server.js

const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();
const port = 5500;

let documents = [];

app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname, 'public')));

app.get('/documents', (req, res) => {
    res.json(documents);
});

app.post('/uploadDocument', (req, res) => {
    const document = req.body;
    documents.push(document);
    res.json({ message: 'Document uploaded successfully' });
});

app.get('/admin1', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'admin1.html'));
});

app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index1.html'));
});

app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}/`);
});
