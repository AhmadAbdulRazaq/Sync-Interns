const questions = [
    {
        question: "What is the capital of France?",
        choices: ["Paris", "Berlin", "London"],
        correct: "Paris"
    },
    {
        question: "Which planet is known as the 'Red Planet'?",
        choices: ["Mars", "Venus", "Mercury"],
        correct: "Mars"
    },
    
    {
        question: "What is the largest mammal in the world?",
        choices: ["Elephant", "Blue Whale", "Giraffe"],
        correct: "Blue Whale"
    },
    {
        question: "What is the tallest mountain in the world?",
        choices: ["Mount Kilimanjaro", "Mount Fuji", "Mount Everest"],
        correct: "Mount Everest"
    },
    {
        question: "Which gas do plants absorb from the atmosphere?",
        choices: ["Oxygen", "Nitrogen", "Carbon Dioxide"],
        correct: "Carbon Dioxide"
    },
    {
        question: "Which element has the chemical symbol 'H'?",
        choices: ["Hydrogen", "Helium", "Carbon"],
        correct: "Hydrogen"
    },
    {
        question: "What is the largest continent on Earth?",
        choices: ["Africa", "Europe", "Asia"],
        correct: "Asia"
    },
    {
        question: "What is the capital of Japan?",
        choices: ["Beijing", "Tokyo", "Seoul"],
        correct: "Tokyo"
    },
    {
        question: "What is the largest ocean in the world?",
        choices: ["Atlantic Ocean", "Pacific Ocean", "Arctic Ocean"],
        correct: "Pacific Ocean"
    },
    {
        question: "What is the largest organ in human body?",
        choices: ["Liver", "Skin", "Brain"],
        correct: "Skin"
    },
    
    
];

let currentQuestion = 0;
let score = 0;

function displayQuestion() {
    if (currentQuestion < questions.length) {
        const questionElement = document.getElementById("question");
        const choicesElement = document.getElementById("choices");
        const choices = questions[currentQuestion].choices;

        questionElement.textContent = `Question ${currentQuestion + 1}: ${questions[currentQuestion].question}`;
        choicesElement.innerHTML = "";

        for (let i = 0; i < choices.length; i++) {
            const button = document.createElement("button");
            button.textContent = `${String.fromCharCode(65 + i)}. ${choices[i]}`;
            button.id = `choice${String.fromCharCode(65 + i)}`;
            button.onclick = () => checkAnswer(choices[i]);
            choicesElement.appendChild(button);
        }
    } else {
        showResults();
    }
}

function checkAnswer(selectedAnswer) {
    const correctAnswer = questions[currentQuestion].correct;

    if (selectedAnswer === correctAnswer) {
        score++;
    }

    currentQuestion++;
    displayQuestion();
}

function showResults() {
    const quizElement = document.getElementById("quiz");
    const resultsElement = document.getElementById("results");
    const scoreElement = document.getElementById("score");
    const resultGifElement = document.getElementById("resultGif");

    quizElement.style.display = "none";
    resultsElement.style.display = "block";
    scoreElement.textContent = score ;

    if (score >= 6) { 
        resultGifElement.innerHTML = '<img src="winner.jpg" alt="Winner">';
    } else {
        resultGifElement.innerHTML = '<img src="tryagain.jpg" alt="Loser">';
    }
}

displayQuestion();
